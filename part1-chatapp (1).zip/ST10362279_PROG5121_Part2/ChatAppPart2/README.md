# PROG5121 PoE — Part 2: QuickChat Sending Messages

**Student Number:** ST10362279 | **IDE:** Apache NetBeans | **Build:** Maven | **Tests:** JUnit 5 | **CI:** GitHub Actions

## What Part 2 adds
- Users can only send messages after a successful login (Part 1 code reused).
- Shows **"Welcome to QuickChat."** and a numeric menu: 1) Send Messages, 2) Show recently sent messages ("Coming Soon."), 3) Quit.
- A `while` loop keeps the app running until the user picks 3.
- The user chooses how many messages to enter; a `for` loop only allows that many.
- Each message gets a random 10-digit ID, a message number (loop counter), a recipient check (+27), a 250-character check and a hash like `00:0:HITONIGHT`.
- Send / Disregard / Store options. Stored messages are written to `messages.json`.
- Total messages sent is shown at the end.

## Message class methods
| Method | What it does |
|---|---|
| `checkMessageID()` | ID is not more than 10 characters |
| `checkRecipientCell()` | +27 and max 10 digits (reused Part 1 regex) |
| `checkMessageLength()` | "Message ready to send." or "Message exceeds 250 characters by X; please reduce the size." |
| `createMessageHash()` | First 2 ID digits : message number : first+last word in CAPS |
| `sentMessage(int)` | 1 send / 2 disregard / 3 store |
| `printMessages()` | All messages sent while running |
| `returnTotalMessages()` | Total sent |
| `storeMessage()` | My own method that writes the messages to JSON |

## Run
Open the folder in NetBeans (File > Open Project), Run `ChatApp`, and Test with `mvn test` (13 Login tests + 13 Message tests).

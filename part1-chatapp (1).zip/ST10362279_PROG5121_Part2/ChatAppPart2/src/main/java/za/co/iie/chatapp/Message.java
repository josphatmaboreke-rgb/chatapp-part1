package za.co.iie.chatapp;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * My Message class for PROG5121 PoE Part 2 (QuickChat - Sending Messages).
 * Student Number: ST10362279
 *
 * I keep all my message logic in here (no Scanner input in this class) so that
 * every method can be tested with JUnit, the same way I did my Login class in Part 1.
 */
public class Message {

    // I use these constants so I don't repeat "magic numbers" in my code.
    public static final int MAX_MESSAGE_LENGTH = 250;
    public static final String JSON_FILE = "messages.json";

    // I share these lists between all messages so I can print and count them later.
    private static final List<String> sentMessages = new ArrayList<>();
    private static final List<String> storedMessagesJson = new ArrayList<>();
    private static int totalMessagesSent = 0;

    private static final Random random = new Random();

    // My details for one single message.
    private final String messageId;
    private final int messageNumber;
    private final String recipient;
    private final String messageText;
    private final String messageHash;

    /** I create a message with a randomly generated ten-digit ID. */
    public Message(int messageNumber, String recipient, String messageText) {
        this(generateMessageId(), messageNumber, recipient, messageText);
    }

    /** I also allow a fixed ID so my unit tests can check the hash (e.g. 00:0:HITONIGHT). */
    public Message(String messageId, int messageNumber, String recipient, String messageText) {
        this.messageId = messageId;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
    }

    /**
     * I generate a random ten-digit number. I pad it with zeros using String.format
     * so that it is ALWAYS exactly ten characters (even if it starts with 0).
     */
    public static String generateMessageId() {
        long number = (long) (random.nextDouble() * 10_000_000_000L);
        return String.format("%010d", number);
    }

    /** I make sure the message ID is not more than ten characters. */
    public boolean checkMessageID() {
        return messageId != null && messageId.length() <= 10;
    }

    /** I return the "Message ID generated" text that the brief asks for. */
    public String getMessageIdStatus() {
        return "Message ID generated: " + messageId;
    }

    /**
     * I reuse my Part 1 regex idea: the number must start with the +27 international
     * code followed by no more than ten digits.
     *
     * Reference: Oracle (2024) Class Pattern (java.util.regex), Java SE 17 API Documentation.
     * Available at: https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/regex/Pattern.html
     */
    public String checkRecipientCell() {
        if (recipient != null && recipient.matches("^\\+27\\d{1,10}$")) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    /** I check that the message is 250 characters or less, and say by how much it is over if not. */
    public String checkMessageLength() {
        int length = (messageText == null) ? 0 : messageText.length();
        if (length <= MAX_MESSAGE_LENGTH) {
            return "Message ready to send.";
        }
        int over = length - MAX_MESSAGE_LENGTH;
        return "Message exceeds 250 characters by " + over + "; please reduce the size.";
    }

    /**
     * I build my message hash using string manipulation:
     * first two digits of the ID (substring) : message number : first word + last word, in CAPS.
     * I strip punctuation so "tonight?" becomes "TONIGHT".
     */
    public String createMessageHash() {
        String firstTwo = messageId.substring(0, 2);
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0].replaceAll("[^A-Za-z0-9]", "");
        String lastWord = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");
        return (firstTwo + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    /**
     * I let the user choose what happens to the message:
     * 1 = Send, 2 = Disregard, 3 = Store to send later.
     */
    public String sentMessage(int choice) {
        switch (choice) {
            case 1:
                sentMessages.add(getMessageDetails());
                totalMessagesSent++;
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete the message.";
            case 3:
                storeMessage();
                return "Message successfully stored.";
            default:
                return "Invalid option, please choose 1, 2 or 3.";
        }
    }

    /** I show the details in the order the brief wants: ID, Hash, Recipient, Message. */
    public String getMessageDetails() {
        return "Message ID: " + messageId
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + messageText;
    }

    /** I return every message sent while the program is running. */
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent.";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < sentMessages.size(); i++) {
            sb.append(sentMessages.get(i));
            if (i < sentMessages.size() - 1) {
                sb.append("\n----------------\n");
            }
        }
        return sb.toString();
    }

    /** I return how many messages have actually been sent. */
    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

    /**
     * My own storeMessage() method. I researched JSON and build the JSON text myself
     * with a StringBuilder (so I don't need an extra library), then write it to messages.json
     * with FileWriter.
     *
     * Reference: Ecma International (2017) ECMA-404 The JSON Data Interchange Syntax.
     * Available at: https://www.json.org/json-en.html
     * Reference: Oracle (2024) Class FileWriter, Java SE 17 API Documentation.
     * Available at: https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/io/FileWriter.html
     */
    public boolean storeMessage() {
        String json = toJson();
        storedMessagesJson.add(json);

        StringBuilder file = new StringBuilder("[\n");
        for (int i = 0; i < storedMessagesJson.size(); i++) {
            file.append("  ").append(storedMessagesJson.get(i));
            file.append(i < storedMessagesJson.size() - 1 ? ",\n" : "\n");
        }
        file.append("]");

        // I use try-with-resources so the file always closes, even if something fails.
        try (FileWriter writer = new FileWriter(JSON_FILE)) {
            writer.write(file.toString());
            return true;
        } catch (IOException e) {
            System.out.println("Could not save message to JSON: " + e.getMessage());
            return false;
        }
    }

    /** I turn this message into one JSON object. */
    public String toJson() {
        return "{\"messageId\": \"" + escape(messageId) + "\", "
                + "\"messageNumber\": " + messageNumber + ", "
                + "\"messageHash\": \"" + escape(messageHash) + "\", "
                + "\"recipient\": \"" + escape(recipient) + "\", "
                + "\"message\": \"" + escape(messageText) + "\"}";
    }

    // I escape quotes and backslashes so my JSON stays valid.
    private static String escape(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    /** I clear my lists - I only use this in my unit tests so each test starts fresh. */
    public static void resetForTesting() {
        sentMessages.clear();
        storedMessagesJson.clear();
        totalMessagesSent = 0;
    }

    public String getMessageId() {
        return messageId;
    }

    public String getMessageHash() {
        return messageHash;
    }
}

package za.co.iie.chatapp;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * My JUnit 5 tests for the Message class (Part 2), using the brief's test data.
 * Student Number: ST10362279
 */
public class MessageTest {

    // My test data from the brief.
    private static final String MSG1 = "Hi Mike, can you join us for dinner tonight?";
    private static final String MSG2 = "Hi Keegan, did you receive the payment?";

    @BeforeEach
    public void setUp() {
        // I reset the shared lists so every test starts clean.
        Message.resetForTesting();
    }

    @Test
    public void testMessageLengthSuccess() {
        Message m = new Message(0, "+27718693002", MSG1);
        assertEquals("Message ready to send.", m.checkMessageLength());
    }

    @Test
    public void testMessageLengthFailure() {
        // I build a 260 character message so it is 10 over the limit.
        String longText = "a".repeat(260);
        Message m = new Message(0, "+27718693002", longText);
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.", m.checkMessageLength());
    }

    @Test
    public void testRecipientCellSuccess() {
        Message m = new Message(0, "+27718693002", MSG1);
        assertEquals("Cell phone number successfully captured.", m.checkRecipientCell());
    }

    @Test
    public void testRecipientCellFailure() {
        Message m = new Message(1, "08575975889", MSG2);
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                m.checkRecipientCell());
    }

    @Test
    public void testMessageHashTestCase1() {
        // I use an ID starting with 00 and message number 0, like the brief's example.
        Message m = new Message("0012345678", 0, "+27718693002", MSG1);
        assertEquals("00:0:HITONIGHT", m.createMessageHash());
    }

    @Test
    public void testMessageHashesInLoop() {
        // I test the rest of the hashes in a loop, using my loop counter as the message number.
        String[] messages = {MSG1, MSG2};
        String[] expected = {"00:0:HITONIGHT", "00:1:HIPAYMENT"};
        for (int i = 0; i < messages.length; i++) {
            Message m = new Message("0098765432", i, "+27718693002", messages[i]);
            assertEquals(expected[i], m.createMessageHash());
        }
    }

    @Test
    public void testMessageHashUsesRandomId() {
        Message m = new Message(0, "+27718693002", MSG1);
        String expected = m.getMessageId().substring(0, 2) + ":0:HITONIGHT";
        assertEquals(expected, m.getMessageHash());
    }

    @Test
    public void testMessageIdCreated() {
        Message m = new Message(0, "+27718693002", MSG1);
        assertTrue(m.checkMessageID());
        assertEquals(10, m.getMessageId().length());
        assertEquals("Message ID generated: " + m.getMessageId(), m.getMessageIdStatus());
    }

    @Test
    public void testSentMessageSend() {
        Message m = new Message(0, "+27718693002", MSG1);
        assertEquals("Message successfully sent.", m.sentMessage(1));
    }

    @Test
    public void testSentMessageDisregard() {
        Message m = new Message(1, "08575975889", MSG2);
        assertEquals("Press 0 to delete the message.", m.sentMessage(2));
    }

    @Test
    public void testSentMessageStore() {
        Message m = new Message(0, "+27718693002", MSG1);
        assertEquals("Message successfully stored.", m.sentMessage(3));
    }

    @Test
    public void testTotalMessagesAndPrint() {
        // Test data: message 1 is sent, message 2 is discarded, so only 1 is counted.
        Message m1 = new Message(0, "+27718693002", MSG1);
        Message m2 = new Message(1, "08575975889", MSG2);
        m1.sentMessage(1);
        m2.sentMessage(2);
        assertEquals(1, Message.returnTotalMessages());
        assertTrue(Message.printMessages().contains(MSG1));
        assertFalse(Message.printMessages().contains(MSG2));
    }

    @Test
    public void testStoreMessageJson() {
        Message m = new Message("0012345678", 0, "+27718693002", MSG1);
        assertTrue(m.storeMessage());
        assertTrue(m.toJson().contains("\"messageHash\": \"00:0:HITONIGHT\""));
    }
}
